export * from './../compiled-types/src/pages/index';
export { default } from './../compiled-types/src/pages/index';