export * from './../compiled-types/node_modules/next/router';
export { default } from './../compiled-types/node_modules/next/router';