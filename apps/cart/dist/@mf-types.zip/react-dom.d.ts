export * from './compiled-types/node_modules/react-dom/index';
export { default } from './compiled-types/node_modules/react-dom/index';