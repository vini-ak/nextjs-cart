import React from "react";
export declare const PriceSection: () => React.JSX.Element;
