import React from "react";
import { DefaultButtonProps } from "./types";
export declare const DefaultButton: (props: DefaultButtonProps) => React.JSX.Element;
